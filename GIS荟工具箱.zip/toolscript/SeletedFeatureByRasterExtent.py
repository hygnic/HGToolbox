# -*- coding:utf-8 -*-
# -------------------------------------------
# Name:              SeletedFeatureByRasterExtent
# Author:            Hygnic
# Created on:        2023/1/24 22:42
# Version:           
# Reference:         
"""
Description:         根据栅格与矢量的空间关系来选择矢量
Usage:               
"""
# -------------------------------------------
import arcpy


